public class HomeWork1 {
    public static void main(String[] args) {
//        1부터 100까지의 숫자를 모두 더해서 출력해보자!
        int i = 1;
        int sum = 0;

        for(i = 1; i <=100; i++){
            sum += i;
        }
        System.out.println("1부터 100까지의 합 =" + sum);
    }

}

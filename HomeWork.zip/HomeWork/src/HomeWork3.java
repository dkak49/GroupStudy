import java.util.Random;
public class HomeWork3 {
    public static void main(String[] args) {
        Random rand = new Random();
        int i = 0;

        while (i < 1) {
            int diceA = (int) (Math.random() * 6) + 1;
            int diceB = rand.nextInt(6) + 1;
            int diceC = rand.nextInt(6) + 1;

            if (diceA > diceB && diceA > diceC) {
                System.out.println("주사위 A의 승리");
            } else if (diceB > diceA && diceB > diceC) {
                System.out.println("주사위 B의 승리");
            } else if (diceC > diceA && diceC > diceB) {
                System.out.println("주사위 C의 승리");}
                else
                    System.out.println("승자는 없다");
                i++;
            }
        }
    }

